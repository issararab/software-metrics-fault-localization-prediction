package rfc;

class RFC3 {
	
	public void x() {
		a("1");
		a(1);
	}
	
}