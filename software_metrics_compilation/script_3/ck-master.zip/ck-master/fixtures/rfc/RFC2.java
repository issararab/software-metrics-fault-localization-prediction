package rfc;

public class RFC2 {

	private String x;
	
	public RFC2() {
		this("a");
	}
	
	public RFC2(String x) {
		this.x = x;
	}

}
